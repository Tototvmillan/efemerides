Corrección aplicada al error de compilación:

ERROR:
resource style/Theme.Material3.DayNight.NoActionBar not found

Solución aplicada:
Se reemplazó el theme del AndroidManifest por un theme nativo de Android:
@android:style/Theme.DeviceDefault.Light.NoActionBar

Archivo corregido:
app/src/main/AndroidManifest.xml

Vuelve a compilar en Android Studio:
Build > Build APK(s)
