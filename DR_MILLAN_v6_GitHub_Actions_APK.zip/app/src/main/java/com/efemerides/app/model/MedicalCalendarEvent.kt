package com.efemerides.app.model

data class MedicalCalendarEvent(
    val id: Int,
    val month: Int,
    val day: Int,
    val specialty: String,
    val title: String,
    val description: String
)
