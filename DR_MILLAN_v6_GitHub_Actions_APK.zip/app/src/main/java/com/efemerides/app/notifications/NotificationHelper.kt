package com.efemerides.app.notifications

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.annotation.RequiresPermission
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.efemerides.app.data.EfemeridesRepository
import com.efemerides.app.data.MedicalContentRepository
import com.efemerides.app.model.RemoteDailyContent

object NotificationHelper {
    const val CHANNEL_ID = "efemerides_daily"

    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val channel = NotificationChannel(CHANNEL_ID, "Efemérides y medicina diarias", NotificationManager.IMPORTANCE_DEFAULT)
            manager.createNotificationChannel(channel)
        }
    }

    @RequiresPermission(Manifest.permission.POST_NOTIFICATIONS)
    fun showDaily(context: Context, remoteContent: RemoteDailyContent? = null) {
        createChannel(context)
        val todayItems = EfemeridesRepository.today()
        val efemerideText = if (todayItems.isNotEmpty()) {
            todayItems.joinToString(" • ") { it.title }
        } else {
            "Hoy no hay efemérides cargadas para esta fecha."
        }

        val text = if (remoteContent != null) {
            buildString {
                append("Efeméride: ")
                append(efemerideText)
                append("\nFrase médica: ")
                append(remoteContent.phrase)
                append(" — ")
                append(remoteContent.author)
                append("\nAnécdota médica: ")
                append(remoteContent.anecdoteTitle)
                append(" (")
                append(remoteContent.anecdoteYear)
                append("). ")
                append(remoteContent.anecdoteText)
            }
        } else {
            val phrase = MedicalContentRepository.phraseOfDay()
            val anecdote = MedicalContentRepository.anecdoteOfDay()
            buildString {
                append("Efeméride: ")
                append(efemerideText)
                append("\nFrase médica: ")
                append(phrase.text)
                append(" — ")
                append(phrase.author)
                append("\nAnécdota médica: ")
                append(anecdote.title)
                append(" (")
                append(anecdote.year)
                append("). ")
                append(anecdote.text)
            }
        }

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Contenido diario")
            .setContentText("Tienes una efeméride, una frase médica y una anécdota histórica médica.")
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)

        NotificationManagerCompat.from(context).notify(1001, builder.build())
    }
}
