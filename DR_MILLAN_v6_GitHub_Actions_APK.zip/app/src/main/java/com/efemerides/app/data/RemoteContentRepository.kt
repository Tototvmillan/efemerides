package com.efemerides.app.data

import com.efemerides.app.model.RemoteDailyContent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class RemoteContentRepository {
    suspend fun fetchDailyContent(): Result<RemoteDailyContent> = withContext(Dispatchers.IO) {
        try {
            val url = URL(ApiConfig.BASE_URL)
            val connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 10000
                readTimeout = 10000
                setRequestProperty("Accept", "application/json")
            }

            val code = connection.responseCode
            if (code !in 200..299) {
                return@withContext Result.failure(IllegalStateException("HTTP $code"))
            }

            val body = connection.inputStream.bufferedReader().use { it.readText() }
            val json = JSONObject(body)

            val content = RemoteDailyContent(
                phrase = json.optString("phrase"),
                author = json.optString("author"),
                anecdoteTitle = json.optString("anecdoteTitle"),
                anecdoteYear = json.optString("anecdoteYear"),
                anecdoteText = json.optString("anecdoteText")
            )

            if (content.phrase.isBlank() || content.author.isBlank() || content.anecdoteTitle.isBlank() || content.anecdoteText.isBlank()) {
                Result.failure(IllegalStateException("JSON incompleto"))
            } else {
                Result.success(content)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
