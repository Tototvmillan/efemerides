package com.efemerides.app.data

import com.efemerides.app.model.MedicalAnecdote
import com.efemerides.app.model.MedicalPhrase
import java.time.LocalDate

object MedicalContentRepository {

    private val classicOccupationalPhrases = listOf(
        MedicalPhrase(1, "Bernardino Ramazzini", "Pregunta al paciente en qué trabaja; el oficio también orienta el diagnóstico."),
        MedicalPhrase(2, "William Osler", "Escuchar al paciente sigue siendo una de las rutas más seguras hacia el diagnóstico."),
        MedicalPhrase(3, "Hipócrates", "La vida es breve, el arte largo, la ocasión fugaz y el juicio difícil."),
        MedicalPhrase(4, "Salud ocupacional", "Prevenir riesgos en el trabajo protege la salud, la productividad y la dignidad humana."),
        MedicalPhrase(5, "Medicina del trabajo", "El mejor tratamiento de muchos daños laborales sigue siendo una prevención bien diseñada."),
        MedicalPhrase(6, "Ergonomía clínica", "Cuando el trabajo se adapta a la persona, disminuye el daño y mejora el desempeño."),
        MedicalPhrase(7, "Vigilancia de la salud", "Observar tendencias tempranas evita accidentes tardíos."),
        MedicalPhrase(8, "Salud pública", "Cada intervención preventiva bien hecha ahorra sufrimiento futuro.")
    )

    private val genericThemes = listOf(
        "La clínica rigurosa comienza con una observación metódica y humana.",
        "La prevención es más poderosa cuando se integra al trabajo cotidiano.",
        "La salud del trabajador depende del cuerpo, la mente y el entorno laboral.",
        "El buen juicio médico requiere escuchar, explorar y contextualizar.",
        "La seguridad laboral es una forma concreta de respeto a la persona.",
        "La medicina de calidad combina evidencia, prudencia y empatía.",
        "El seguimiento oportuno cambia más desenlaces que la improvisación.",
        "La historia clínica bien construida evita errores posteriores.",
        "La valoración funcional debe mirar capacidades reales y contexto.",
        "Toda intervención preventiva gana fuerza cuando el equipo participa.",
        "Medir exposición, frecuencia e intensidad mejora la decisión clínica.",
        "El trabajo digno exige entornos seguros y vigilancia continua."
    )

    val phrases: List<MedicalPhrase> = (1..365).map { day ->
        when {
            day <= classicOccupationalPhrases.size -> classicOccupationalPhrases[day - 1]
            else -> {
                val theme = genericThemes[(day - 1) % genericThemes.size]
                val author = when (day % 6) {
                    0 -> "Reflexión clínica"
                    1 -> "Salud ocupacional"
                    2 -> "Medicina del trabajo"
                    3 -> "Prevención de riesgos"
                    4 -> "Práctica médica"
                    else -> "Gestión clínica"
                }
                MedicalPhrase(day, author, theme)
            }
        }
    }

    private val anecdoteSeeds = listOf(
        Pair("El estetoscopio de Laennec", "1816") to "René Laennec improvisó un cilindro de papel para auscultar sin contacto directo y esa idea abrió paso al estetoscopio moderno.",
        Pair("Semmelweis y el lavado de manos", "1847") to "Ignaz Semmelweis mostró que una medida simple de higiene podía reducir de forma importante la fiebre puerperal.",
        Pair("La primera vacuna de Jenner", "1796") to "Edward Jenner demostró que la inoculación con viruela vacuna podía proteger contra la viruela humana.",
        Pair("Röntgen y los rayos X", "1895") to "El hallazgo de los rayos X cambió de manera decisiva el diagnóstico por imagen.",
        Pair("La insulina", "1921") to "El aislamiento de la insulina transformó la evolución de la diabetes mellitus.",
        Pair("La penicilina", "1928") to "La observación de Fleming inició la era antibiótica moderna.",
        Pair("Ramazzini y los oficios", "1700") to "Bernardino Ramazzini propuso estudiar las enfermedades vinculadas al trabajo y preguntar siempre por el oficio del paciente.",
        Pair("Florence Nightingale y los datos", "1850s") to "El uso sistemático de estadísticas hospitalarias ayudó a demostrar causas prevenibles de mortalidad.",
        Pair("Ramón y Cajal", "finales del siglo XIX") to "La observación microscópica rigurosa consolidó la doctrina neuronal.",
        Pair("Primer trasplante cardiaco célebre", "1967") to "La cirugía cardiaca alcanzó una nueva frontera con el trasplante humano que dio la vuelta al mundo.",
        Pair("Tomografía computarizada", "1970s") to "La tomografía permitió entender la anatomía interna con un detalle antes impensable.",
        Pair("Resonancia magnética", "1980s") to "La resonancia agregó una nueva dimensión diagnóstica sin radiación ionizante."
    )

    val anecdotes: List<MedicalAnecdote> = (1..365).map { day ->
        val seed = anecdoteSeeds[(day - 1) % anecdoteSeeds.size]
        val pair = seed.first
        val title = pair.first
        val year = pair.second
        val extra = when (day % 6) {
            0 -> " Su valor histórico está en cómo integró observación, método y cambio de práctica."
            1 -> " También recuerda que una innovación pequeña puede tener un impacto enorme en salud."
            2 -> " La lección principal es que la evidencia tarda en aceptarse, pero termina transformando la práctica."
            3 -> " Ese episodio sigue citándose como ejemplo de curiosidad clínica bien dirigida."
            4 -> " Desde la medicina del trabajo, invita a pensar en prevención y vigilancia temprana."
            else -> " Su legado permanece en la formación clínica y en la seguridad del paciente."
        }
        MedicalAnecdote(day, title, year, seed.second + extra)
    }

    fun phraseOfDay(): MedicalPhrase {
        val day = LocalDate.now().dayOfYear
        return phrases[(day - 1) % phrases.size]
    }

    fun anecdoteOfDay(): MedicalAnecdote {
        val day = LocalDate.now().dayOfYear
        return anecdotes[(day - 1) % anecdotes.size]
    }

    fun occupationalHighlights(): List<MedicalPhrase> = classicOccupationalPhrases
}
