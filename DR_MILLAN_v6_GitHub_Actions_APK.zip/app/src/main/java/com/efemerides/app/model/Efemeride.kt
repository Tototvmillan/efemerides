package com.efemerides.app.model

data class Efemeride(
    val id: Int,
    val month: Int,
    val day: Int,
    val title: String,
    val description: String,
    val scope: Scope,
    val category: Category,
    val country: String
)

enum class Scope { MEXICO, MUNDO }
enum class Category { HISTORIA, CIENCIA, CULTURA, DERECHOS_HUMANOS, AMBIENTE, POLITICA, EDUCACION }
