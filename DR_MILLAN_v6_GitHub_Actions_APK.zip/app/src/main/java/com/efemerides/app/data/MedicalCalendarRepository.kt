package com.efemerides.app.data

import com.efemerides.app.model.MedicalCalendarEvent

object MedicalCalendarRepository {
    val events = listOf(
        MedicalCalendarEvent(1,1,4,"Rehabilitación","Día Mundial del Braille","Relevante para rehabilitación, accesibilidad y discapacidad."),
        MedicalCalendarEvent(2,2,4,"Oncología","Día Mundial contra el Cáncer","Fecha para prevención, detección oportuna y continuidad asistencial."),
        MedicalCalendarEvent(3,2,15,"Oncología pediátrica","Día Internacional del Cáncer Infantil","Enfocado en diagnóstico temprano y acompañamiento integral."),
        MedicalCalendarEvent(4,3,3,"Otorrinolaringología","Día Mundial de la Audición","Promueve prevención, tamizaje y acceso a tratamiento."),
        MedicalCalendarEvent(5,3,24,"Neumología / Infectología","Día Mundial de la Tuberculosis","Recuerda vigilancia, diagnóstico y adherencia terapéutica."),
        MedicalCalendarEvent(6,4,7,"Salud pública","Día Mundial de la Salud","Fecha amplia para campañas sanitarias y educación comunitaria."),
        MedicalCalendarEvent(7,4,17,"Hemofilia","Día Mundial de la Hemofilia","Visibiliza diagnóstico y tratamiento oportuno."),
        MedicalCalendarEvent(8,4,28,"Medicina del trabajo","Día Mundial de la Seguridad y Salud en el Trabajo","Eje de prevención de riesgos laborales y cultura de seguridad."),
        MedicalCalendarEvent(9,5,5,"Higiene de manos","Día Mundial de la Higiene de Manos","Refuerza seguridad del paciente y prevención de infecciones."),
        MedicalCalendarEvent(10,5,12,"Enfermería","Día Internacional de la Enfermería","Reconoce el valor del cuidado profesional."),
        MedicalCalendarEvent(11,5,17,"Hipertensión","Día Mundial de la Hipertensión","Relevante para tamizaje y control crónico."),
        MedicalCalendarEvent(12,5,31,"Neumología / Adicciones","Día Mundial sin Tabaco","Clave para prevención de enfermedad respiratoria y cáncer."),
        MedicalCalendarEvent(13,6,14,"Hematología","Día Mundial del Donante de Sangre","Fomenta donación segura y suficiente."),
        MedicalCalendarEvent(14,7,28,"Hepatología","Día Mundial contra la Hepatitis","Impulsa diagnóstico y vacunación."),
        MedicalCalendarEvent(15,8,1,"Lactancia","Semana Mundial de la Lactancia","Promueve nutrición temprana y salud maternoinfantil."),
        MedicalCalendarEvent(16,9,10,"Salud mental","Día Mundial para la Prevención del Suicidio","Relevante para detección, apoyo y referencia oportuna."),
        MedicalCalendarEvent(17,9,17,"Seguridad del paciente","Día Mundial de la Seguridad del Paciente","Subraya sistemas seguros y aprendizaje organizacional."),
        MedicalCalendarEvent(18,9,21,"Neurología","Día Mundial del Alzheimer","Enfocado en cuidado, detección y apoyo familiar."),
        MedicalCalendarEvent(19,9,29,"Cardiología","Día Mundial del Corazón","Promueve prevención cardiovascular."),
        MedicalCalendarEvent(20,10,10,"Salud mental","Día Mundial de la Salud Mental","Visibiliza prevención, tratamiento y estigma."),
        MedicalCalendarEvent(21,10,12,"Artritis","Día Mundial de la Artritis","Importante para diagnóstico funcional y rehabilitación."),
        MedicalCalendarEvent(22,10,16,"Reanimación","Día Mundial de la Reanimación Cardiopulmonar","Impulsa capacitación comunitaria."),
        MedicalCalendarEvent(23,11,14,"Endocrinología","Día Mundial de la Diabetes","Relevante para prevención, detección y control."),
        MedicalCalendarEvent(24,11,17,"Neonatología","Día Mundial del Niño Prematuro","Subraya seguimiento y soporte especializado."),
        MedicalCalendarEvent(25,12,1,"Infectología","Día Mundial del Sida","Promueve prevención, diagnóstico y tratamiento."),
        MedicalCalendarEvent(26,12,3,"Discapacidad / Rehabilitación","Día Internacional de las Personas con Discapacidad","Invita a accesibilidad, inclusión y enfoque funcional.")
    )
}
