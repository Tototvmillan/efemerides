package com.efemerides.app.data

import com.efemerides.app.model.RemoteDailyContent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

class AdminContentRepository {
    suspend fun listContent(): Result<List<RemoteDailyContent>> = withContext(Dispatchers.IO) {
        try {
            val conn = (URL(ApiConfig.BASE_URL.replace("/api/daily-content", "/api/admin/content")).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 10000
                readTimeout = 10000
                setRequestProperty("Accept", "application/json")
            }
            val code = conn.responseCode
            if (code !in 200..299) return@withContext Result.failure(IllegalStateException("HTTP $code"))
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val arr = JSONArray(body)
            val result = mutableListOf<RemoteDailyContent>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                result.add(
                    RemoteDailyContent(
                        phrase = o.optString("phrase"),
                        author = o.optString("author"),
                        anecdoteTitle = o.optString("anecdoteTitle"),
                        anecdoteYear = o.optString("anecdoteYear"),
                        anecdoteText = o.optString("anecdoteText")
                    )
                )
            }
            Result.success(result)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun createContent(item: RemoteDailyContent): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val conn = (URL(ApiConfig.BASE_URL.replace("/api/daily-content", "/api/admin/content")).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 10000
                readTimeout = 10000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
            }
            val payload = JSONObject()
                .put("phrase", item.phrase)
                .put("author", item.author)
                .put("anecdoteTitle", item.anecdoteTitle)
                .put("anecdoteYear", item.anecdoteYear)
                .put("anecdoteText", item.anecdoteText)
                .toString()
            OutputStreamWriter(conn.outputStream).use { it.write(payload) }
            val code = conn.responseCode
            if (code !in 200..299) return@withContext Result.failure(IllegalStateException("HTTP $code"))
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
