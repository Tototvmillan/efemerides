package com.efemerides.app.data

import com.efemerides.app.model.Category
import com.efemerides.app.model.Efemeride
import com.efemerides.app.model.Scope
import java.time.LocalDate

object EfemeridesRepository {
    val all = listOf(
        Efemeride(1,1,1,"Año Nuevo","Celebración del inicio del año en gran parte del mundo.",Scope.MUNDO,Category.CULTURA,"Mundo"),
        Efemeride(2,1,27,"Día Internacional en Memoria de las Víctimas del Holocausto","Jornada de memoria, educación y prevención contra el antisemitismo y el odio.",Scope.MUNDO,Category.DERECHOS_HUMANOS,"Mundo"),
        Efemeride(3,2,5,"Promulgación de la Constitución Mexicana de 1917","Se promulga la Constitución Política de los Estados Unidos Mexicanos.",Scope.MEXICO,Category.HISTORIA,"México"),
        Efemeride(4,2,14,"Día del Amor y la Amistad","Celebración popular vinculada a la amistad y el afecto.",Scope.MUNDO,Category.CULTURA,"Varios países"),
        Efemeride(5,2,24,"Día de la Bandera","Conmemoración cívica dedicada a uno de los símbolos patrios de México.",Scope.MEXICO,Category.EDUCACION,"México"),
        Efemeride(6,3,8,"Día Internacional de la Mujer","Fecha para reconocer la lucha por la igualdad y los derechos de las mujeres.",Scope.MUNDO,Category.DERECHOS_HUMANOS,"Mundo"),
        Efemeride(7,3,18,"Expropiación Petrolera","Aniversario del decreto de expropiación petrolera en México en 1938.",Scope.MEXICO,Category.HISTORIA,"México"),
        Efemeride(8,3,21,"Natalicio de Benito Juárez","Conmemoración del nacimiento de Benito Juárez.",Scope.MEXICO,Category.HISTORIA,"México"),
        Efemeride(9,4,22,"Día Internacional de la Madre Tierra","Promueve la protección ambiental y el desarrollo sostenible.",Scope.MUNDO,Category.AMBIENTE,"Mundo"),
        Efemeride(10,5,1,"Día Internacional del Trabajo","Conmemoración de las luchas laborales y los derechos de las personas trabajadoras.",Scope.MUNDO,Category.DERECHOS_HUMANOS,"Mundo"),
        Efemeride(11,5,5,"Batalla de Puebla","Conmemoración de la victoria mexicana sobre el ejército francés en 1862.",Scope.MEXICO,Category.HISTORIA,"México"),
        Efemeride(12,5,15,"Día del Maestro","Reconocimiento al trabajo docente en México.",Scope.MEXICO,Category.EDUCACION,"México"),
        Efemeride(13,6,5,"Día Mundial del Medio Ambiente","Fecha orientada a sensibilizar sobre la protección ambiental.",Scope.MUNDO,Category.AMBIENTE,"Mundo"),
        Efemeride(14,7,20,"Llegada del hombre a la Luna","Conmemoración del alunizaje del Apolo 11 en 1969.",Scope.MUNDO,Category.CIENCIA,"Mundo"),
        Efemeride(15,8,9,"Día Internacional de los Pueblos Indígenas","Reconocimiento a los derechos y aportes de los pueblos indígenas.",Scope.MUNDO,Category.DERECHOS_HUMANOS,"Mundo"),
        Efemeride(16,9,13,"Niños Héroes","Conmemoración de la defensa del Castillo de Chapultepec.",Scope.MEXICO,Category.HISTORIA,"México"),
        Efemeride(17,9,15,"Grito de Independencia","Conmemoración del inicio de la Independencia de México.",Scope.MEXICO,Category.HISTORIA,"México"),
        Efemeride(18,9,16,"Inicio de la Independencia de México","Fecha cívica nacional de gran relevancia histórica.",Scope.MEXICO,Category.HISTORIA,"México"),
        Efemeride(19,9,16,"Día Internacional de la Preservación de la Capa de Ozono","Busca crear conciencia sobre la protección de la capa de ozono.",Scope.MUNDO,Category.AMBIENTE,"Mundo"),
        Efemeride(20,9,21,"Día Internacional de la Paz","Efeméride promovida para fortalecer los ideales de paz.",Scope.MUNDO,Category.DERECHOS_HUMANOS,"Mundo"),
        Efemeride(21,10,12,"Día de la Nación Pluricultural","Fecha de reflexión histórica y cultural en México.",Scope.MEXICO,Category.CULTURA,"México"),
        Efemeride(22,10,24,"Día de las Naciones Unidas","Recuerda la entrada en vigor de la Carta de las Naciones Unidas.",Scope.MUNDO,Category.POLITICA,"Mundo"),
        Efemeride(23,11,20,"Inicio de la Revolución Mexicana","Conmemoración del movimiento revolucionario de 1910.",Scope.MEXICO,Category.HISTORIA,"México"),
        Efemeride(24,11,20,"Día Universal del Niño","Jornada enfocada en la infancia, sus derechos y bienestar.",Scope.MUNDO,Category.DERECHOS_HUMANOS,"Mundo"),
        Efemeride(25,12,10,"Día de los Derechos Humanos","Conmemoración de la adopción de la Declaración Universal de los Derechos Humanos.",Scope.MUNDO,Category.DERECHOS_HUMANOS,"Mundo"),
        Efemeride(26,12,12,"Día de la Virgen de Guadalupe","Fecha de gran importancia religiosa y cultural en México.",Scope.MEXICO,Category.CULTURA,"México")
    )

    fun today(): List<Efemeride> {
        val now = LocalDate.now()
        return all.filter { it.month == now.monthValue && it.day == now.dayOfMonth }
    }
}
