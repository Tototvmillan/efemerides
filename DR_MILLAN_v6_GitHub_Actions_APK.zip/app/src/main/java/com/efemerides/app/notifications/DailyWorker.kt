package com.efemerides.app.notifications

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.efemerides.app.data.RemoteContentStore
import kotlinx.coroutines.flow.first

class DailyWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        if (ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.POST_NOTIFICATIONS)
            == PackageManager.PERMISSION_GRANTED) {
            val remote = RemoteContentStore(applicationContext).remoteContentFlow.first()
            NotificationHelper.showDaily(applicationContext, remote)
        }
        return Result.success()
    }
}
