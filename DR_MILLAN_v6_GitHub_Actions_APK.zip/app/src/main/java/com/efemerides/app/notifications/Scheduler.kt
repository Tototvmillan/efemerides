package com.efemerides.app.notifications

import android.content.Context
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

object Scheduler {
    fun scheduleDaily(context: Context) {
        val work = PeriodicWorkRequestBuilder<DailyWorker>(24, TimeUnit.HOURS).build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            "daily_efemerides",
            ExistingPeriodicWorkPolicy.UPDATE,
            work
        )
    }

    fun scheduleRemoteSync(context: Context) {
        val work = PeriodicWorkRequestBuilder<RemoteSyncWorker>(24, TimeUnit.HOURS).build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            "remote_sync_daily_content",
            ExistingPeriodicWorkPolicy.UPDATE,
            work
        )
    }
}
