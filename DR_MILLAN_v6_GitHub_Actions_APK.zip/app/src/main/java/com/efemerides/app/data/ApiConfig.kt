package com.efemerides.app.data

object ApiConfig {
    // Sustituye por tu backend real.
    // Ejemplo local para pruebas en emulador Android:
    // const val BASE_URL = "http://10.0.2.2:3000/api/daily-content"
    // Ejemplo en red local:
    // const val BASE_URL = "http://192.168.1.20:3000/api/daily-content"
    const val BASE_URL = "http://10.0.2.2:3000/api/daily-content"
}
