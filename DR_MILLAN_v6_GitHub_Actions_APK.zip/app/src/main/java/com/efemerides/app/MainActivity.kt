package com.efemerides.app

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.LaunchedEffect
import com.efemerides.app.notifications.NotificationHelper
import com.efemerides.app.notifications.Scheduler
import com.efemerides.app.ui.EfemeridesApp
import com.efemerides.app.ui.theme.EfemeridesTheme

class MainActivity : ComponentActivity() {
    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        NotificationHelper.createChannel(this)
        Scheduler.scheduleDaily(this)
        Scheduler.scheduleRemoteSync(this)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            EfemeridesTheme {
                LaunchedEffect(Unit) { }
                EfemeridesApp()
            }
        }
    }
}
