package com.efemerides.app.model

data class MedicalPhrase(
    val id: Int,
    val author: String,
    val text: String
)

data class MedicalAnecdote(
    val id: Int,
    val title: String,
    val year: String,
    val text: String
)
