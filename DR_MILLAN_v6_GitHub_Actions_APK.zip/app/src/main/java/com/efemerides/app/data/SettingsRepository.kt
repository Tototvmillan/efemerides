package com.efemerides.app.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.mutablePreferencesOf
import androidx.datastore.preferences.preferencesDataStoreFile
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import androidx.datastore.preferences.core.edit
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class SettingsRepository(private val context: Context) {
    private val dataStore: DataStore<Preferences> = PreferenceDataStoreFactory.create(
        produceFile = { context.preferencesDataStoreFile("settings.preferences_pb") }
    )

    private object Keys {
        val notifyEnabled = booleanPreferencesKey("notify_enabled")
        val notifyHour = intPreferencesKey("notify_hour")
    }

    val notifyEnabledFlow: Flow<Boolean> = dataStore.data.map { it[Keys.notifyEnabled] ?: true }
    val notifyHourFlow: Flow<Int> = dataStore.data.map { it[Keys.notifyHour] ?: 8 }

    suspend fun setNotifyEnabled(value: Boolean) {
        dataStore.edit { it[Keys.notifyEnabled] = value }
    }

    suspend fun setNotifyHour(value: Int) {
        dataStore.edit { it[Keys.notifyHour] = value }
    }
}
