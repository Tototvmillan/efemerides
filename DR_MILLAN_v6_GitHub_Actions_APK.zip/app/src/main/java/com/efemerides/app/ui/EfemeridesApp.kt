package com.efemerides.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SmallTopAppBar
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.platform.LocalContext
import com.efemerides.app.data.AdminContentRepository
import com.efemerides.app.data.EfemeridesRepository
import com.efemerides.app.data.MedicalCalendarRepository
import com.efemerides.app.data.MedicalContentRepository
import com.efemerides.app.data.RemoteContentStore
import com.efemerides.app.data.SettingsRepository
import com.efemerides.app.model.Category
import com.efemerides.app.model.Efemeride
import com.efemerides.app.model.MedicalCalendarEvent
import com.efemerides.app.model.RemoteDailyContent
import com.efemerides.app.model.Scope
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EfemeridesApp() {
    val context = LocalContext.current
    val settingsRepository = remember { SettingsRepository(context) }
    val remoteStore = remember { RemoteContentStore(context) }
    val adminRepo = remember { AdminContentRepository() }
    val scopeC = rememberCoroutineScope()

    var selectedTab by remember { mutableStateOf(0) }
    val tabs = listOf("Inicio", "Admin")

    var query by remember { mutableStateOf("") }
    var selectedScope by remember { mutableStateOf("Ambos") }
    var selectedCategory by remember { mutableStateOf("Todas") }
    var favoritesOnly by remember { mutableStateOf(false) }
    var favorites by remember { mutableStateOf(setOf<Int>()) }
    var selectedSpecialty by remember { mutableStateOf("Todas") }

    val notifyEnabled by settingsRepository.notifyEnabledFlow.collectAsState(initial = true)
    val notifyHour by settingsRepository.notifyHourFlow.collectAsState(initial = 8)
    val remoteContent by remoteStore.remoteContentFlow.collectAsState(initial = null)
    val remoteSyncedAt by remoteStore.syncedAtFlow.collectAsState(initial = null)

    val todayItems = remember { EfemeridesRepository.today() }
    val phraseOfDay = remember { MedicalContentRepository.phraseOfDay() }
    val anecdoteOfDay = remember { MedicalContentRepository.anecdoteOfDay() }
    val occupationalHighlights = remember { MedicalContentRepository.occupationalHighlights() }
    val calendarEvents = remember { MedicalCalendarRepository.events }

    val categories = listOf("Todas") + Category.entries.map { it.name.replace("_", " ") }
    val scopeOptions = listOf("Ambos", "México", "Mundo")

    val filtered = remember(query, selectedScope, selectedCategory, favoritesOnly, favorites) {
        EfemeridesRepository.all.filter { item ->
            val q = query.trim().lowercase()
            val matchQuery = q.isBlank() ||
                item.title.lowercase().contains(q) ||
                item.description.lowercase().contains(q) ||
                item.country.lowercase().contains(q)

            val matchScope = when (selectedScope) {
                "México" -> item.scope == Scope.MEXICO
                "Mundo" -> item.scope == Scope.MUNDO
                else -> true
            }

            val matchCategory = selectedCategory == "Todas" || item.category.name.replace("_", " ") == selectedCategory
            val matchFav = !favoritesOnly || favorites.contains(item.id)
            matchQuery && matchScope && matchCategory && matchFav
        }
    }

    Scaffold(
        modifier = Modifier.safeDrawingPadding(),
        topBar = {
            SmallTopAppBar(
                title = { Text("Medicina y Efemérides") },
                actions = {
                    Text("DR. MILLÁN", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(end = 16.dp))
                }
            )
        },
        contentWindowInsets = WindowInsets.statusBars
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            TabRow(selectedTabIndex = selectedTab) {
                tabs.forEachIndexed { index, title ->
                    Tab(selected = selectedTab == index, onClick = { selectedTab = index }, text = { Text(title) })
                }
            }

            if (selectedTab == 0) {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item {
                        HeroCard(
                            phrase = remoteContent?.phrase ?: phraseOfDay.text,
                            author = remoteContent?.author ?: phraseOfDay.author,
                            syncedAt = remoteSyncedAt
                        )
                    }
                    item {
                        SearchCard(query = query, onQuery = { query = it })
                    }
                    item {
                        PremiumStatsCard(
                            todayCount = todayItems.size,
                            phraseCount = 365,
                            anecdoteCount = 365,
                            specialtyCount = calendarEvents.map { it.specialty }.distinct().size
                        )
                    }
                    item {
                        DailyMedicalCard(
                            anecdoteTitle = remoteContent?.anecdoteTitle ?: anecdoteOfDay.title,
                            anecdoteYear = remoteContent?.anecdoteYear ?: anecdoteOfDay.year,
                            anecdoteText = remoteContent?.anecdoteText ?: anecdoteOfDay.text
                        )
                    }
                    item {
                        TodayEfemeridesCard(todayItems = todayItems)
                    }
                    item {
                        FiltersCard(
                            scopeOptions = scopeOptions,
                            selectedScope = selectedScope,
                            onScope = { selectedScope = it },
                            categories = categories,
                            selectedCategory = selectedCategory,
                            onCategory = { selectedCategory = it },
                            favoritesOnly = favoritesOnly,
                            onFavoritesOnly = { favoritesOnly = it }
                        )
                    }
                    item {
                        SettingsCard(
                            notifyEnabled = notifyEnabled,
                            notifyHour = notifyHour,
                            onNotifyEnabled = { value -> scopeC.launch { settingsRepository.setNotifyEnabled(value) } }
                        )
                    }
                    item {
                        OccupationalCard(occupationalHighlights.map { "${it.author}: ${it.text}" })
                    }
                    item {
                        CalendarCard(
                            specialties = calendarEvents.map { it.specialty }.distinct(),
                            selectedSpecialty = selectedSpecialty,
                            onSpecialty = { selectedSpecialty = it },
                            events = calendarEvents.filter { selectedSpecialty == "Todas" || it.specialty == selectedSpecialty }
                        )
                    }
                    item {
                        Text("Resultados (${filtered.size})", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    }
                    items(filtered) { item ->
                        EfemerideCard(
                            item = item,
                            isFavorite = favorites.contains(item.id),
                            onToggleFavorite = {
                                favorites = if (favorites.contains(item.id)) favorites - item.id else favorites + item.id
                            }
                        )
                    }
                }
            } else {
                AdminPanel(adminRepo)
            }
        }
    }
}

@Composable
private fun HeroCard(phrase: String, author: String, syncedAt: String?) {
    ElevatedCard(
        shape = RoundedCornerShape(30.dp),
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.elevatedCardColors()
    ) {
        Column(
            Modifier
                .fillMaxWidth()
                .background(MaterialTheme.colorScheme.primaryContainer)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.AutoAwesome, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Versión 6", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
            }
            Text("DR. MILLÁN – Medicina y Efemérides", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("“$phrase”", style = MaterialTheme.typography.bodyLarge)
            Text("— $author", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
            if (syncedAt != null) {
                Text("Sincronizado desde backend: $syncedAt", style = MaterialTheme.typography.bodySmall)
            } else {
                Text("Modo local activo", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun PremiumStatsCard(todayCount: Int, phraseCount: Int, anecdoteCount: Int, specialtyCount: Int) {
    ElevatedCard(shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Resumen rápido", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                AssistChip(onClick = {}, label = { Text("Hoy: $todayCount efemérides") })
                AssistChip(onClick = {}, label = { Text("$phraseCount frases") })
                AssistChip(onClick = {}, label = { Text("$anecdoteCount anécdotas") })
                AssistChip(onClick = {}, label = { Text("$specialtyCount especialidades") })
            }
        }
    }
}

@Composable
private fun SearchCard(query: String, onQuery: (String) -> Unit) {
    ElevatedCard(shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            OutlinedTextField(
                value = query,
                onValueChange = onQuery,
                modifier = Modifier.fillMaxWidth(),
                leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
                label = { Text("Buscar por evento, país o tema") }
            )
        }
    }
}

@Composable
private fun DailyMedicalCard(anecdoteTitle: String, anecdoteYear: String, anecdoteText: String) {
    ElevatedCard(shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Anécdota histórica médica del día", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            Text("$anecdoteTitle ($anecdoteYear)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(anecdoteText)
        }
    }
}

@Composable
private fun TodayEfemeridesCard(todayItems: List<Efemeride>) {
    ElevatedCard(shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Efemérides del día", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            if (todayItems.isEmpty()) {
                Text("No hay efemérides precargadas para hoy.")
            } else {
                todayItems.forEach {
                    Text("• ${it.day}/${it.month} — ${it.title}")
                    Text(it.description, style = MaterialTheme.typography.bodySmall)
                    Divider()
                }
            }
        }
    }
}

@Composable
private fun FiltersCard(
    scopeOptions: List<String>,
    selectedScope: String,
    onScope: (String) -> Unit,
    categories: List<String>,
    selectedCategory: String,
    onCategory: (String) -> Unit,
    favoritesOnly: Boolean,
    onFavoritesOnly: (Boolean) -> Unit
) {
    ElevatedCard(shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Filtros", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                scopeOptions.forEach { opt ->
                    FilterChip(selected = selectedScope == opt, onClick = { onScope(opt) }, label = { Text(opt) })
                }
            }
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                categories.forEach { cat ->
                    FilterChip(selected = selectedCategory == cat, onClick = { onCategory(cat) }, label = { Text(cat) })
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Solo favoritas")
                Spacer(Modifier.width(12.dp))
                Switch(checked = favoritesOnly, onCheckedChange = onFavoritesOnly)
            }
        }
    }
}

@Composable
private fun SettingsCard(notifyEnabled: Boolean, notifyHour: Int, onNotifyEnabled: (Boolean) -> Unit) {
    ElevatedCard(shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.Notifications, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Notificación diaria", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Activada")
                Spacer(Modifier.width(12.dp))
                Switch(checked = notifyEnabled, onCheckedChange = onNotifyEnabled)
            }
            Text("Hora configurada: ${String.format("%02d:00", notifyHour)}")
            Text("La app conserva la sincronización diaria con backend y respaldo local.")
        }
    }
}

@Composable
private fun OccupationalCard(items: List<String>) {
    ElevatedCard(shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.MedicalServices, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Medicina del trabajo", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            }
            Text("Selección especial enfocada en salud ocupacional y valoración clínico-laboral.")
            items.forEach { Text("• $it") }
        }
    }
}

@Composable
private fun CalendarCard(
    specialties: List<String>,
    selectedSpecialty: String,
    onSpecialty: (String) -> Unit,
    events: List<MedicalCalendarEvent>
) {
    ElevatedCard(shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Calendario médico por especialidad", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                (listOf("Todas") + specialties).distinct().forEach {
                    FilterChip(selected = selectedSpecialty == it, onClick = { onSpecialty(it) }, label = { Text(it) })
                }
            }
            events.forEach {
                Text("• ${it.day}/${it.month} — ${it.specialty}: ${it.title}")
                Text(it.description, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun EfemerideCard(item: Efemeride, isFavorite: Boolean, onToggleFavorite: () -> Unit) {
    ElevatedCard(shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("${item.day}/${item.month}", style = MaterialTheme.typography.labelLarge)
                    Text(item.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                }
                IconButton(onClick = onToggleFavorite) {
                    Icon(
                        imageVector = if (isFavorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                        contentDescription = null
                    )
                }
            }
            Text(item.description)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                AssistChip(onClick = {}, label = { Text(item.country) }, leadingIcon = { Icon(Icons.Filled.Public, contentDescription = null) })
                AssistChip(onClick = {}, label = { Text(item.category.name.replace("_", " ")) })
                AssistChip(onClick = {}, label = { Text(if (item.scope == Scope.MEXICO) "México" else "Mundo") })
            }
        }
    }
}

@Composable
private fun AdminPanel(repo: AdminContentRepository) {
    val scope = rememberCoroutineScope()
    var phrase by remember { mutableStateOf("") }
    var author by remember { mutableStateOf("") }
    var anecdoteTitle by remember { mutableStateOf("") }
    var anecdoteYear by remember { mutableStateOf("") }
    var anecdoteText by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Listo") }
    var items by remember { mutableStateOf(listOf<RemoteDailyContent>()) }

    LaunchedEffect(Unit) {
        repo.listContent().onSuccess { items = it }.onFailure { status = "No se pudo cargar backend" }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            ElevatedCard(shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.AdminPanelSettings, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Panel Admin", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    }
                    Text("Agrega frases y anécdotas al backend de ejemplo.")
                    OutlinedTextField(value = phrase, onValueChange = { phrase = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Frase médica") })
                    OutlinedTextField(value = author, onValueChange = { author = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Autor") })
                    OutlinedTextField(value = anecdoteTitle, onValueChange = { anecdoteTitle = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Título de anécdota") })
                    OutlinedTextField(value = anecdoteYear, onValueChange = { anecdoteYear = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Año") })
                    OutlinedTextField(value = anecdoteText, onValueChange = { anecdoteText = it }, modifier = Modifier.fillMaxWidth(), label = { Text("Texto de anécdota") })
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = {
                            scope.launch {
                                val result = repo.createContent(
                                    RemoteDailyContent(
                                        phrase = phrase,
                                        author = author,
                                        anecdoteTitle = anecdoteTitle,
                                        anecdoteYear = anecdoteYear,
                                        anecdoteText = anecdoteText
                                    )
                                )
                                result.onSuccess {
                                    status = "Contenido agregado"
                                    repo.listContent().onSuccess { items = it }
                                    phrase = ""
                                    author = ""
                                    anecdoteTitle = ""
                                    anecdoteYear = ""
                                    anecdoteText = ""
                                }.onFailure {
                                    status = "Error al guardar en backend"
                                }
                            }
                        }) { Text("Guardar") }

                        Button(onClick = {
                            scope.launch {
                                repo.listContent().onSuccess {
                                    items = it
                                    status = "Contenido actualizado"
                                }.onFailure {
                                    status = "No se pudo actualizar"
                                }
                            }
                        }) { Text("Recargar") }
                    }
                    Text(status, style = MaterialTheme.typography.bodySmall)
                }
            }
        }

        item {
            Text("Contenido actual del backend", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
        }

        items(items) { item ->
            ElevatedCard(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(item.phrase, fontWeight = FontWeight.SemiBold)
                    Text(item.author, style = MaterialTheme.typography.bodySmall)
                    Text("${item.anecdoteTitle} (${item.anecdoteYear})", fontWeight = FontWeight.SemiBold)
                    Text(item.anecdoteText, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}
