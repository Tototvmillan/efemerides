package com.efemerides.app.model

data class RemoteDailyContent(
    val phrase: String,
    val author: String,
    val anecdoteTitle: String,
    val anecdoteYear: String,
    val anecdoteText: String
)
