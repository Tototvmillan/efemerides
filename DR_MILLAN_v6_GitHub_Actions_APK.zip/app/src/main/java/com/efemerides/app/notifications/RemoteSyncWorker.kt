package com.efemerides.app.notifications

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.efemerides.app.data.RemoteContentRepository
import com.efemerides.app.data.RemoteContentStore
import java.time.LocalDateTime

class RemoteSyncWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        val repo = RemoteContentRepository()
        val result = repo.fetchDailyContent()
        return if (result.isSuccess) {
            val content = result.getOrNull()
            if (content != null) {
                RemoteContentStore(applicationContext).save(content, LocalDateTime.now().toString())
            }
            Result.success()
        } else {
            Result.retry()
        }
    }
}
