package com.efemerides.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStoreFile
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import com.efemerides.app.model.RemoteDailyContent
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class RemoteContentStore(private val context: Context) {
    private val dataStore: DataStore<Preferences> = PreferenceDataStoreFactory.create(
        produceFile = { context.preferencesDataStoreFile("remote_content.preferences_pb") }
    )

    private object Keys {
        val phrase = stringPreferencesKey("phrase")
        val author = stringPreferencesKey("author")
        val anecdoteTitle = stringPreferencesKey("anecdote_title")
        val anecdoteYear = stringPreferencesKey("anecdote_year")
        val anecdoteText = stringPreferencesKey("anecdote_text")
        val syncedAt = stringPreferencesKey("synced_at")
    }

    val remoteContentFlow: Flow<RemoteDailyContent?> = dataStore.data.map { prefs ->
        val phrase = prefs[Keys.phrase]
        val author = prefs[Keys.author]
        val anecdoteTitle = prefs[Keys.anecdoteTitle]
        val anecdoteYear = prefs[Keys.anecdoteYear]
        val anecdoteText = prefs[Keys.anecdoteText]
        if (phrase != null && author != null && anecdoteTitle != null && anecdoteYear != null && anecdoteText != null) {
            RemoteDailyContent(
                phrase = phrase,
                author = author,
                anecdoteTitle = anecdoteTitle,
                anecdoteYear = anecdoteYear,
                anecdoteText = anecdoteText
            )
        } else {
            null
        }
    }

    val syncedAtFlow: Flow<String?> = dataStore.data.map { it[Keys.syncedAt] }

    suspend fun save(content: RemoteDailyContent, syncedAt: String) {
        dataStore.edit { prefs ->
            prefs[Keys.phrase] = content.phrase
            prefs[Keys.author] = content.author
            prefs[Keys.anecdoteTitle] = content.anecdoteTitle
            prefs[Keys.anecdoteYear] = content.anecdoteYear
            prefs[Keys.anecdoteText] = content.anecdoteText
            prefs[Keys.syncedAt] = syncedAt
        }
    }
}
