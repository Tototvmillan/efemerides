Proyecto Android Studio: DR. MILLÁN – Medicina y Efemérides v6

Incluye:
- diseño renovado tipo premium
- nombre visible DR. MILLÁN
- pestañas Inicio y Admin
- backend Express de ejemplo
- sincronización diaria de contenido remoto
- respaldo con contenido local
- 365 frases médicas
- 365 anécdotas históricas médicas
- sección especial de medicina del trabajo
- calendario médico por especialidad
- efemérides de México y del mundo
- notificación diaria

No incluye sección de congresos.

Cómo probar:
1. entra a la carpeta backend
2. ejecuta npm install
3. ejecuta npm start
4. abre el proyecto Android en Android Studio
5. compila con Build > Build APK(s)

Endpoint base del ejemplo:
http://10.0.2.2:3000/api/daily-content
