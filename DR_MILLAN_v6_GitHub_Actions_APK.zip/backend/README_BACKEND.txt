Backend de ejemplo

1. Instala Node.js
2. Entra a la carpeta backend
3. Ejecuta:
   npm install
   npm start

Endpoint:
http://localhost:3000/api/daily-content

Para emulador Android:
la app ya apunta a http://10.0.2.2:3000/api/daily-content

JSON esperado:
{
  "phrase": "Texto",
  "author": "Autor",
  "anecdoteTitle": "Título",
  "anecdoteYear": "Año",
  "anecdoteText": "Contenido"
}
