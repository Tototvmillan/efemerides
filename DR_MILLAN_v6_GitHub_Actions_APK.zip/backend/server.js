const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

let dailyContent = [
  {
    phrase: "Pregunta al paciente en qué trabaja; el oficio también orienta el diagnóstico.",
    author: "Bernardino Ramazzini",
    anecdoteTitle: "Ramazzini y los oficios",
    anecdoteYear: "1700",
    anecdoteText: "Bernardino Ramazzini describió enfermedades relacionadas con oficios y recomendó preguntar siempre por el trabajo del paciente."
  },
  {
    phrase: "Escuchar al paciente sigue siendo una de las rutas más seguras hacia el diagnóstico.",
    author: "William Osler",
    anecdoteTitle: "El estetoscopio de Laennec",
    anecdoteYear: "1816",
    anecdoteText: "Laennec improvisó un cilindro de papel para auscultar y abrió paso al estetoscopio moderno."
  },
  {
    phrase: "La vida es breve, el arte largo, la ocasión fugaz y el juicio difícil.",
    author: "Hipócrates",
    anecdoteTitle: "Semmelweis y el lavado de manos",
    anecdoteYear: "1847",
    anecdoteText: "Semmelweis mostró que una medida simple de higiene podía reducir de forma importante la fiebre puerperal."
  }
];

app.get("/api/daily-content", (req, res) => {
  const day = new Date().getDate();
  const item = dailyContent[day % dailyContent.length];
  res.json(item);
});

app.get("/api/admin/content", (req, res) => {
  res.json(dailyContent);
});

app.post("/api/admin/content", (req, res) => {
  const body = req.body || {};
  const item = {
    phrase: body.phrase || "",
    author: body.author || "",
    anecdoteTitle: body.anecdoteTitle || "",
    anecdoteYear: body.anecdoteYear || "",
    anecdoteText: body.anecdoteText || ""
  };
  if (!item.phrase || !item.author || !item.anecdoteTitle || !item.anecdoteText) {
    return res.status(400).json({ error: "Faltan campos obligatorios" });
  }
  dailyContent.push(item);
  res.status(201).json(item);
});

app.put("/api/admin/content/:index", (req, res) => {
  const index = Number(req.params.index);
  if (Number.isNaN(index) || index < 0 || index >= dailyContent.length) {
    return res.status(404).json({ error: "Índice no encontrado" });
  }
  dailyContent[index] = { ...dailyContent[index], ...req.body };
  res.json(dailyContent[index]);
});

app.delete("/api/admin/content/:index", (req, res) => {
  const index = Number(req.params.index);
  if (Number.isNaN(index) || index < 0 || index >= dailyContent.length) {
    return res.status(404).json({ error: "Índice no encontrado" });
  }
  const removed = dailyContent.splice(index, 1);
  res.json(removed[0]);
});

app.get("/", (req, res) => {
  res.send("Backend de Efemérides Pro activo");
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor escuchando en http://localhost:${PORT}`);
});
